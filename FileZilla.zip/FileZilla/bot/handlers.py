from telegram import Update, ReplyKeyboardMarkup, InputFile
from telegram.ext import CallbackContext
from bot.database import add_file, get_files, delete_file

def start(update: Update, context: CallbackContext) -> None:
    keyboard = [
        ['Профиль👁‍🗨', 'Загрузить📥'],
        ['Выгрузить📤', 'Информацияℹ'],
        ['Администратор👨‍💼']
    ]

    reply_markup = ReplyKeyboardMarkup(keyboard)

    update.message.reply_text(
        "Привет! Я бот, который может хранить ваши файлы. Вы можете загрузить файлы, отправив их мне, и я сохраню их для вас.",
        reply_markup=reply_markup
    )

def upload_file(update: Update, context: CallbackContext) -> None:
    user = update.effective_user
    user_id = user.id
    username = user.username

    # Проверяем, есть ли файл в сообщении
    if update.effective_message.document:
        file = update.effective_message.document
        file_name = file.file_name
        file_id = file.file_id

        # Сохраняем файл в базу данных
        add_file(user_id=update.effective_user.id, username=update.effective_user.username,
                 file_data=file_id, file_name=file_name)

        # Отправляем подтверждающее сообщение
        context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="Файл успешно загружен."
        )
    else:
        # Если файл не был прикреплен, отправляем сообщение об ошибке
        context.bot.send_message(
            chat_id=update.effective_chat.id,
            text="Пожалуйста, прикрепите файл для загрузки."
        )

def download_file(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    files = get_files(user_id)
    for file in files:
        context.bot.send_document(chat_id=user_id, document=InputFile(file.file_data, filename=file.file_name), caption=file.file_description)

def delete_file_handler(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    file_name = update.message.text.split(' ', 1)[1]
    delete_file(user_id, file_name)
    update.message.reply_text("Файл успешно удален!")

def profile(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    files = get_files(user_id)
    total_size = sum(len(file.file_data) for file in files)
    update.message.reply_text(f"Вы загрузили {len(files)} файлов общим размером {total_size} байт.")

def info(update: Update, context: CallbackContext) -> None:
    update.message.reply_text(
        "Я бот, который может хранить ваши файлы. Вы можете использовать следующие команды:\n"
        "/start - Начать взаимодействие со мной\n"
        "/profile - Показать информацию о вашем профиле и ваших файлах\n"
        "/upload - Загрузить файлы в меня\n"
        "/download - Скачать все ваши файлы\n"
        "/delete <имя файла> - Удалить файл с указанным именем\n"
        "/info - Показать эту информацию\n"
        "/contact_admin - Связаться с администратором"
    )

def contact_admin(update: Update, context: CallbackContext) -> None:
    update.message.reply_text(
        "Вы можете связаться с администратором по следующей ссылке: https://t.me/requiemsoulsss"
    )

print ("--handlers started--")