from sqlalchemy import create_engine, Column, Integer, String, LargeBinary, DateTime, ForeignKey
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    username = Column(String)
    files = relationship("Upload", back_populates="user")

class Upload(Base):
    __tablename__ = 'uploads'

    id = Column(Integer, primary_key=True)
    file_data = Column(LargeBinary)
    file_name = Column(String)
    file_description = Column(String)
    upload_date = Column(DateTime, default=datetime.datetime.utcnow)
    user_id = Column(Integer, ForeignKey('users.id'))
    user = relationship("User", back_populates="files")

engine = create_engine('sqlite:///users.db')
Base.metadata.create_all(engine)

Session = sessionmaker(bind=engine)
session = Session()

def add_file(user_id, username, file_data, file_name):
    user = session.query(User).filter_by(id=user_id).first()
    new_file = Upload(file_data=file_data.encode(), file_name=file_name)
    user.files.append(new_file)
    session.commit()

def get_files(user_id):
    user = session.query(User).filter_by(id=user_id).first()
    files = user.files
    return files

def delete_file(user_id, file_name):
    user = session.query(User).filter_by(id=user_id).first()
    file = session.query(Upload).filter_by(file_name=file_name, user=user).first()
    session.delete(file)
    session.commit()

print ("-db started-")