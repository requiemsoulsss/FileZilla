from telegram import Update, ReplyKeyboardMarkup
from telegram.ext import Updater, CommandHandler, MessageHandler, Filters, CallbackContext
from bot.handlers import start, upload_file, download_file, delete_file_handler, profile, info, contact_admin
import os

def main() -> None:
    updater = Updater(token='Your_Telegram_Bot_API', use_context=True)

    dispatcher = updater.dispatcher
#CommandHandlers
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(MessageHandler(Filters.document, upload_file))
    dispatcher.add_handler(CommandHandler("download", download_file))
    dispatcher.add_handler(CommandHandler("delete", delete_file_handler))
    dispatcher.add_handler(CommandHandler("profile", profile))
    dispatcher.add_handler(CommandHandler("info", info))
    dispatcher.add_handler(CommandHandler("contact_admin", contact_admin))
    
#MessageHandlers    
    dispatcher.add_handler(MessageHandler(Filters.text(['Профиль👁‍🗨']), profile))
    dispatcher.add_handler(MessageHandler(Filters.text(['Загрузить📥']), upload_file))
    dispatcher.add_handler(MessageHandler(Filters.text(['Выгрузить📤']), download_file))
    dispatcher.add_handler(MessageHandler(Filters.text(['Информацияℹ']), info))
    dispatcher.add_handler(MessageHandler(Filters.text(['Администратор👨‍💼']), contact_admin))
    
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()

print ("---bot started---")

