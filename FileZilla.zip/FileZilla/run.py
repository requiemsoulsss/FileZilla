from bot.main import main
print ("===[ Bot developer: @requiemoulsss ]===")
if __name__ == "__main__":
    main()
